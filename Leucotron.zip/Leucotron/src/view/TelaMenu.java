package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.ListSelectionModel;

import controller.InputListenerMenu;
import model.Usuario;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class TelaMenu extends JFrame {	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4652322067257249915L;
	
	private InputListenerMenu listener;
	private JPanel contentPane;
	private JPanel panel;
	private JButton btnLogout;
	private JLabel label;
	private JLabel label_1;
	
	public TelaMenu() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(TelaMenu.class.getResource("/imagens/iconeleucotron.jpg")));
		this.setResizable(false); //Fixar dimensoes
		this.setLocationRelativeTo(null); //Setar Tela no meio
		setTitle("LEUCOTRON - CLIENTE");
		initialize();
		setActionCommand();
		listener = new InputListenerMenu(this);
		listenerInitialize();
		}
	
	private void initialize() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);		
		contentPane = new JPanel();
		setBounds(100, 100, 450, 300);
		setLocationRelativeTo(null);		
		contentPane.setLayout(new BorderLayout());
		setContentPane(contentPane);
		getContentPane().add(getPanel(), BorderLayout.CENTER);
	}
	
	private void listenerInitialize() {
		getBtnLogout().addActionListener(listener);
	}
	
	private JPanel getPanel() {
		if (panel == null) {
			panel = new JPanel();
			panel.setLayout(null);
			panel.add(getLabel_1());
			panel.add(getBtnLogout());
			panel.add(getLabel());
		}
		return panel;
	}
		
	private JButton getBtnLogout() {
		if (btnLogout == null) {
			btnLogout = new JButton("Logout");
			btnLogout.setBounds(280, 212, 144, 36);
		}
		return btnLogout;
	}
	
	private void setActionCommand() {
		getBtnLogout().setActionCommand("LOGOUT");
	}
	
	private JLabel getLabel() {
		if (label == null) {
			label = new JLabel("");
			label.setIcon(new ImageIcon(TelaMenu.class.getResource("/imagens/grey-technology-background_1035-9343.jpg")));
			label.setBounds(-14, -31, 448, 304);
		}
		return label;
	}
	private JLabel getLabel_1() {
		if (label_1 == null) {
			label_1 = new JLabel("");
			label_1.setIcon(new ImageIcon(TelaMenu.class.getResource("/imagens/banner-leucotron.jpg")));
			label_1.setBounds(-54, 0, 508, 188);
		}
		return label_1;
	}
}
