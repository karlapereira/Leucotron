package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import view.TelaEditarUsuario;
import view.TelaLogin;
import view.TelaMenu;

public class InputListenerMenu implements ActionListener{

	private TelaMenu tela;
	
	public InputListenerMenu (TelaMenu tela) {
		this.tela = tela;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {		
		if (event.getActionCommand() == "USUARIOS") {
			usuarios();
		}
		else if (event.getActionCommand() == "LOGOUT") {
			logout();
		}

	}

	private void usuarios() {
		try {
			tela.dispose();
			new TelaEditarUsuario().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}

	private void logout() {
		try {
			//Setar o usuario atual para null
			tela.dispose();
			new TelaLogin().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	private void update() {
		try {
			SwingUtilities.updateComponentTreeUI(this.tela);
			//tela.dispose();
			//new MenuAdmin().setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
