package controller;

import view.TelaLogin;

public class Main {
	public static void main(String[] args) {
		new TelaLogin().setVisible(true);
	}
}
